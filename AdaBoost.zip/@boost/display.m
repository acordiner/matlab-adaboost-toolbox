%DISPLAY Display properties of the AdaBoost object

% Copyright 2008 Alister Cordiner

function display(bst)

    disp(bst);

end