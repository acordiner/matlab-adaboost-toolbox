%DISP Display properties of the AdaBoost object

% Copyright 2008 Alister Cordiner

function disp(bst)

    disp(char(bst));

end