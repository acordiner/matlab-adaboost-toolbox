%PURELIN Pure linear input function
%
% Usage:
%   out = purelin(in)
%
%  See also HARDLIM, HARDLIMS

function out = purelin(in)

    out = in;
    
end